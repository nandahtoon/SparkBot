SparkBot: Engineering Academy — Native Android App Build Guide
===============================================================

This archive is completely self-contained (includes the synced web bundle and
the Capacitor Android runtime) so you do NOT need to run `npm install`.

Option A — Build APK in Android Studio (Easiest)
------------------------------------------------
1. Unzip this archive.
2. Open Android Studio and choose "Open", then select the `android/` folder.
3. Wait for Gradle Sync to finish.
4. To install directly on a USB-connected Android tablet/phone: click Run (▶).
5. To export an APK file: Build -> Build Bundle(s) / APK(s) -> Build APK(s).
   Output: android/app/build/outputs/apk/debug/app-debug.apk

Option B — Command-Line Gradle Build (JDK 17+ & Android SDK required)
---------------------------------------------------------------------
cd android
./gradlew assembleDebug
# Windows: gradlew.bat assembleDebug
# Output APK: android/app/build/outputs/apk/debug/app-debug.apk
